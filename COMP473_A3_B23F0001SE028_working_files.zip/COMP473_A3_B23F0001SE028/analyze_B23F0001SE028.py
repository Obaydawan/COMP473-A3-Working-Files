import ast
import sys
from collections import defaultdict

if len(sys.argv) != 2:
    raise SystemExit("Usage: python analyze_B23F0001SE028.py legacy_B23F0001SE028.py")

REG = "B23F0001SE028"
source_path = sys.argv[1]
source = open(source_path, encoding="utf-8").read()
tree = ast.parse(source)
functions = {n.name: n for n in tree.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))}
globals_found = {}
for node in tree.body:
    if isinstance(node, (ast.Assign, ast.AnnAssign, ast.AugAssign)):
        targets = node.targets if isinstance(node, ast.Assign) else [node.target]
        for target in targets:
            for child in ast.walk(target):
                if isinstance(child, ast.Name):
                    globals_found[child.id] = node.lineno

class Calls(ast.NodeVisitor):
    def __init__(self):
        self.names = set()
    def visit_Call(self, node):
        if isinstance(node.func, ast.Name) and node.func.id in functions:
            self.names.add(node.func.id)
        self.generic_visit(node)

def complexity(node):
    count = 1
    for item in ast.walk(node):
        if isinstance(item, (ast.If, ast.For, ast.AsyncFor, ast.While, ast.ExceptHandler)):
            count += 1
        elif isinstance(item, ast.IfExp):
            count += 1
        elif isinstance(item, ast.BoolOp):
            count += len(item.values) - 1
    return count

def target_root(node):
    while isinstance(node, (ast.Subscript, ast.Attribute)):
        node = node.value
    return node.id if isinstance(node, ast.Name) else None

class Usage(ast.NodeVisitor):
    def __init__(self, globals_set):
        self.globals_set = globals_set
        self.read = set()
        self.write = set()
    def visit_Name(self, node):
        if node.id in self.globals_set:
            if isinstance(node.ctx, ast.Load):
                self.read.add(node.id)
            elif isinstance(node.ctx, (ast.Store, ast.Del)):
                self.write.add(node.id)
    def visit_Call(self, node):
        mutators = {"append", "extend", "insert", "pop", "remove", "clear", "update", "sort", "setdefault"}
        if isinstance(node.func, ast.Attribute) and node.func.attr in mutators:
            root = target_root(node.func.value)
            if root in self.globals_set:
                self.write.add(root)
        self.generic_visit(node)

calls_by_function = {}
fan_in = defaultdict(set)
for name, node in functions.items():
    visitor = Calls()
    for statement in node.body:
        visitor.visit(statement)
    calls_by_function[name] = sorted(visitor.names)
    for callee in visitor.names:
        fan_in[callee].add(name)

usage = {}
for name, node in functions.items():
    visitor = Usage(set(globals_found))
    for statement in node.body:
        visitor.visit(statement)
    usage[name] = {}
    for global_name in globals_found:
        if global_name in visitor.write:
            usage[name][global_name] = "W"
        elif global_name in visitor.read:
            usage[name][global_name] = "R"
        else:
            usage[name][global_name] = ""

print("REG", REG)
print("\nFUNCTION TABLE")
print("name | calls | fan-out | fan-in | complexity")
for name in functions:
    print(name, "|", ", ".join(calls_by_function[name]) or "-", "|",
          len(calls_by_function[name]), "|", len(fan_in[name]), "|", complexity(functions[name]))

print("\nGLOBAL USAGE TABLE (R=read, W=write)")
print("function | " + " | ".join(globals_found))
for name in functions:
    print(name, "| " + " | ".join(usage[name][g] or "-" for g in globals_found))

untouched = [g for g in globals_found if not any(usage[f][g] for f in functions)]
one_function = [g for g in globals_found if sum(bool(usage[f][g]) for f in functions) == 1]
never_called = [f for f in functions if not fan_in[f] and f != "main"]

print("\nFUNCTIONS WITH FAN-IN 0 OTHER THAN main:", never_called)
print("GLOBALS NO FUNCTION TOUCHES:", untouched)
print("GLOBALS TOUCHED BY EXACTLY ONE FUNCTION:", one_function)

numeric_globals = []
for name in globals_found:
    top_node = next((n for n in tree.body if isinstance(n, (ast.Assign, ast.AnnAssign)) and
                     any(isinstance(x, ast.Name) and x.id == name for t in (n.targets if isinstance(n, ast.Assign) else [n.target]) for x in ast.walk(t))), None)
    if top_node and isinstance(getattr(top_node, "value", None), ast.Constant) and isinstance(top_node.value.value, (int, float)):
        numeric_globals.append(name)
if numeric_globals:
    counts = {g: sum(bool(usage[f][g]) for f in functions) for g in numeric_globals}
    max_count = max(counts.values())
    print("MOST-TOUCHED SINGLE-NUMBER GLOBAL:", [(g, counts[g], [f for f in functions if usage[f][g]]) for g in numeric_globals if counts[g] == max_count])
