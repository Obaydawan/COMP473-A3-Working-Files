# legacy rental tally - variant A
import sys
CL = []
RN = []
RATE = {'T4': 400, 'L2': 250, 'G9': 900}
DISC = [0, 0, 10, 20]
cash = 0
def load(path):
    for ln in open(path):
        f = ln.strip().split('|')
        if f[0] == 'C': CL.append(f)
        if f[0] == 'R': RN.append(f)
def get_cl(cid):
    for c in CL:
        if c[1] == cid: return c
    return None
def price(r):
    c = get_cl(r[2])
    days = int(r[5])
    base = RATE[r[3]] * days
    if c[3] == '3':
        pct = 20
    elif c[3] == '2':
        pct = 10
    fee = 0
    if r[6] == '1' and days > 2:
        fee = 50 * (days - 2)
    elif r[6] == '2':
        fee = 500
    return base - base * pct // 100 + fee
def book(r):
    global cash
    stamp = r[4]
    c = get_cl(r[2])
    if c is None or c[4] != 'A': return 0
    amt = price(r)
    cash += amt
    return amt
def refund(r):
    global cash
    cash -= RATE[r[3]] * int(r[5])
    return cash
def close_day():
    global cash
    print('cash', cash)
    cash = 0
def purge_closed():
    for c in CL:
        if c[4] == 'X': CL.remove(c)
def main():
    load(sys.argv[1])
    for r in RN:
        amt = refund(r) if r[6] == '9' else book(r)
        print(r[1], get_cl(r[2])[2], r[3], amt)
    close_day()
main()
