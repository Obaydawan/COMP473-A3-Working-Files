import sys
from collections import defaultdict

REG = "B23F0001SE028"
if len(sys.argv) != 2:
    raise SystemExit("Usage: python extract_B23F0001SE028.py records_B23F0001SE028.dat")

records = defaultdict(list)
with open(sys.argv[1], encoding="utf-8") as handle:
    for line in handle:
        fields = line.rstrip("\n").split("|")
        if fields and fields[0] in {"C", "R"}:
            records[fields[0]].append(fields)

print("REG", REG)
for record_type in ("C", "R"):
    rows = records[record_type]
    print(f"\nRecord type {record_type}: {len(rows)} records, {len(rows[0]) if rows else 0} fields")
    if not rows:
        continue
    for index in range(len(rows[0])):
        values = [row[index] for row in rows]
        distinct = list(dict.fromkeys(values))
        samples = distinct[:4]
        print(f"Field {index + 1}: distinct={len(distinct)}, samples={samples}")
